TRIMMED LOGOS - drop into the FYP template's img/ folder
=======================================================
  logo1.png   = NUML
  logo2.png   = FE&CS (Faculty of Engineering & Computing)
  logo3.png   = NUML Placement Centre (NPC)
  logo4.png   = R&SI . NUML
  company.png = Industry collaborator (sample = Alberuni Tech;
                replace with your own partner logo if different)

Put these in the img/ folder next to the template HTML, then open
the template in Chrome and Print -> Save as PDF. Your team photos
(member1.jpg, supervisor.jpg, member2.jpg) and app screenshots
(shot1.png, shot2.png) go in the same img/ folder.
